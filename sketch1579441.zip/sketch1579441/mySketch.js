var txts = [] 
var ay = 0.1
var colors = "cdb4db-ffc8dd-ffafcc-bde0fe-a2d2ff".split("-").map(a=>"#"+a)
function setup() {
 createCanvas(windowWidth, windowHeight);
 background(100);
 inputElement =createInput("")
 inputElement.position(50,50)
 inputElement.input(userInput)
 sliderElement= createSlider(-0.3,0.3,0,0.08)//最小值，最大值，預設值，間距
 sliderElement.position(50,150)
 sliderElement.input(setGravity)
 
}

function setGravity(){
 ay = sliderElement.value()
}

function userInput(){
 txts.push({
  text: this.value(),
  x: width/2,
  y: 50,
  vx: random(-5,1),
  vy: 1,
  color: random(colors)
 })
  this.value('')
}

function draw() {
 background(100);
 fill(255)
 textSize(50)
 for (var i =0;i<txts.length;i++){
  let txt =  txts[i]
  fill(txt.color)
  text(txt.text,txt.x,txt.y)//把txt.text文字內容顯示在(txt.x,txt.y)座標上
  txt.x = txt.x + txt.vx
  txt.y = txt.y + txt.vy
  txt.vy = txt.vy + ay
  txt.vy = txt.vy * 0.994
  txt.vx = txt.vx * 0.994
  if(txt.y>height){
   txt.vy = -abs(txt.vy)
  }
 }   
}